---
name: restore-codex-history
description: Diagnose and repair missing Codex Desktop or Codex CLI chat history, session indexes, state_*.sqlite thread metadata, model_provider filtering, archived sessions, and sidebar project grouping by cwd. Use when Codex chats disappear, project groups show "no conversations", restored JSONL sessions do not appear in the Desktop sidebar, or old conversations need to be migrated into a new Codex installation.
---

# Restore Codex History

## Workflow

1. Inspect before editing. Run the bundled script in dry-run mode first:

```bash
python3 "$CODEX_HOME/skills/restore-codex-history/scripts/restore_codex_history.py" diagnose
```

If `CODEX_HOME` is unset, use `~/.codex/skills/restore-codex-history/...`.

2. Back up live state before every write. The script creates timestamped backups under `~/.codex/manual_restore_backup_*` when run with `--apply`; do not skip this for live user data.

3. Repair in small passes. Prefer `--provider`, `--rebuild-index`, and explicit `--assign-cwd THREAD_ID=PATH` fixes over broad guesses.

4. Verify through the same app-server path Desktop uses:

```bash
python3 "$CODEX_HOME/skills/restore-codex-history/scripts/restore_codex_history.py" verify --app-server /Applications/Codex.app/Contents/Resources/codex
```

5. Refresh Desktop only after data verifies. Clear sidebar collapsed state or reload the app if the database is correct but the UI still shows empty groups.

## Common Fixes

Run all commands without `--apply` first.

```bash
# Rebuild ~/.codex/session_index.jsonl from raw JSONL sessions.
python3 scripts/restore_codex_history.py rebuild-index --apply

# Normalize all active threads and session_meta model_provider values.
python3 scripts/restore_codex_history.py fix-provider --provider sub2api --apply

# Move specific conversations into the correct project group.
python3 scripts/restore_codex_history.py assign-cwd \
  --assign-cwd 019e3e5b-df12-7ae0-b747-f5f52f581fa7=/absolute/path/to/project \
  --apply

# Add explicit Desktop sidebar project assignments as a second guardrail.
python3 scripts/restore_codex_history.py assign-projects \
  --assign-cwd 019e3e5b-df12-7ae0-b747-f5f52f581fa7=/absolute/path/to/project \
  --apply
```

## Safety Rules

- Never invent conversations. Only restore from existing JSONL files or known backups.
- Never force a conversation into a project just to make an empty project look non-empty. If a thread merely references `/Users/me/Downloads/file.svg` while its work happened in another project, keep it in the real project.
- Update both `state_*.sqlite` and the JSONL `session_meta.cwd` when changing project grouping. Also update `turn_context.cwd` so future reads are coherent.
- If Desktop returns fewer rows than SQLite, suspect filters first: `model_provider`, `archived`, `thread_source`, `has_user_event`, or `sourceKinds`.
- If app-server verifies correctly but the sidebar still looks stale, inspect `.codex-global-state.json` keys: `electron-saved-workspace-roots`, `active-workspace-roots`, `project-order`, `thread-project-assignments`, and `electron-persisted-atom-state.sidebar-collapsed-groups`.

## References

Read [references/repair-notes.md](references/repair-notes.md) when you need the full troubleshooting checklist, schema notes, or lessons from a real recovery.
