# Codex History Repair Notes

## Files To Inspect

- `~/.codex/sessions/YYYY/MM/DD/*.jsonl`: raw conversations. The first `session_meta` line carries `id`, `cwd`, `source`, `model_provider`, and timestamps.
- `~/.codex/session_index.jsonl`: lightweight index used by some Codex flows. It usually contains `id`, `thread_name`, and `updated_at`.
- `~/.codex/state_*.sqlite`: Desktop thread metadata. The active Desktop DB is often the newest `state_*.sqlite`.
- `~/.codex/.codex-global-state.json`: Desktop sidebar roots, order, project assignments, pinned projects, collapsed groups, and prompt history.
- `~/Library/Application Support/Codex`: Electron cache/user data. Avoid deleting Cookies or Preferences unless the user accepts re-login or app reset risk.

## SQLite Thread Fields That Matter

Use `.schema threads` because app versions change. These fields commonly affect visibility:

- `id`
- `rollout_path`
- `created_at`, `updated_at`, and sometimes `created_at_ms`, `updated_at_ms`
- `source`
- `model_provider`
- `cwd`
- `title`
- `has_user_event`
- `archived`, `archived_at`
- `thread_source`
- `preview`

Desktop `thread/list` can filter by provider, archived status, source kinds, and sort key. A row can exist in SQLite yet not appear in the sidebar if these fields do not match the current app's expectations.

## Project Sidebar Behavior

Codex Desktop project groups are driven mainly by thread `cwd` plus workspace roots in `.codex-global-state.json`.

Useful global-state keys:

- `electron-saved-workspace-roots`: known workspace/project roots.
- `active-workspace-roots`: roots currently active in the sidebar/workspace model.
- `project-order`: sidebar ordering.
- `thread-project-assignments`: explicit mapping from thread id to local or remote project.
- `thread-workspace-root-hints`: discovered root hints.
- `projectless-thread-ids`: threads intentionally not assigned to projects.
- `electron-persisted-atom-state.sidebar-collapsed-groups`: collapsed groups; stale values can make a repaired project look empty or hidden.

For a local explicit assignment:

```json
{
  "THREAD_ID": {
    "projectKind": "local",
    "projectId": "/absolute/project/root",
    "path": "/absolute/project/root",
    "pendingCoreUpdate": false
  }
}
```

## Real Recovery Lessons

In one recovery, all raw JSONL sessions existed and the index had 74 unique ids, but Desktop showed only a few conversations. The root causes were layered:

- Old rows had `model_provider` values like `openai`, `OpenAI`, or `codexapi`, while current config used `sub2api`. Desktop `thread/list` filtered them out.
- Some threads had broad `cwd` values such as `/Users/example/codex-work`, while the sidebar project root was `/Users/example/projects/app` or `/Users/example/projects/logo-maker`.
- The global state had workspace roots, but some repaired projects were collapsed or not active.

The durable fix was:

1. Back up `state_*.sqlite*`, `session_index.jsonl`, `.codex-global-state.json`, and `sessions/`.
2. Normalize DB and JSONL `session_meta.payload.model_provider` to the current provider.
3. Set `has_user_event=1` and `thread_source='user'` for restored user conversations when missing.
4. Reassign only clearly matched project threads by updating SQLite `threads.cwd`, JSONL `session_meta.cwd`, and JSONL `turn_context.cwd`.
5. Add `thread-project-assignments` for high-confidence mappings.
6. Ensure roots are present in `electron-saved-workspace-roots`, `active-workspace-roots`, and `project-order`.
7. Verify with app-server `thread/list`, not just raw SQLite queries.

## Verification Pattern

Start the app-server over stdio and send JSON-RPC:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"clientInfo":{"name":"restore-check","version":"1.0"}}}
{"jsonrpc":"2.0","id":2,"method":"thread/list","params":{"limit":100,"cursor":null,"sortKey":"updated_at","modelProviders":null,"archived":false,"sourceKinds":[]}}
```

Expected checks:

- Count matches active SQLite rows.
- Provider distribution matches the current config.
- CWD counts include the restored project roots.
- `nextCursor` is `null` or further pages are fetched.

## When Not To Reassign

Do not move a thread solely because a path appears in logs or tool output. Examples:

- A UI project thread referencing `/Users/example/Downloads/Group 3.svg` should remain in the UI project if the work changed that project.
- A project setup thread listing `$HOME/Downloads` in shell output should remain in its original workspace.
- A chat about using a shared local tool from another project should stay in the project that owns the task, unless the user's first request clearly says the target is the tool project.
