#!/usr/bin/env python3
"""Diagnose and repair Codex Desktop/CLI history metadata.

The script is intentionally conservative: mutating commands require --apply and
create a timestamped backup before writing.
"""

from __future__ import annotations

import argparse
import collections
import datetime as dt
import json
import os
import pathlib
import shutil
import sqlite3
import subprocess
import sys
from typing import Any


def codex_home_from_args(value: str | None) -> pathlib.Path:
    if value:
        return pathlib.Path(value).expanduser()
    return pathlib.Path(os.environ.get("CODEX_HOME", "~/.codex")).expanduser()


def newest_state_db(codex_home: pathlib.Path) -> pathlib.Path:
    dbs = sorted(
        codex_home.glob("state_*.sqlite"),
        key=lambda p: p.stat().st_mtime if p.exists() else 0,
        reverse=True,
    )
    if not dbs:
        raise SystemExit(f"No state_*.sqlite found under {codex_home}")
    return dbs[0]


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def backup_codex_home(
    codex_home: pathlib.Path,
    db: pathlib.Path,
    reason: str,
    include_sessions: bool = True,
) -> pathlib.Path:
    backup = codex_home / f"manual_restore_backup_{now_stamp()}_{reason}"
    backup.mkdir(parents=True, exist_ok=False)

    for p in [
        db,
        pathlib.Path(str(db) + "-wal"),
        pathlib.Path(str(db) + "-shm"),
        codex_home / "session_index.jsonl",
        codex_home / ".codex-global-state.json",
    ]:
        if p.exists():
            shutil.copy2(p, backup / p.name)

    sessions = codex_home / "sessions"
    if include_sessions and sessions.exists():
        shutil.copytree(sessions, backup / "sessions")

    return backup


def json_loads(line: str) -> dict[str, Any] | None:
    try:
        obj = json.loads(line)
    except Exception:
        return None
    return obj if isinstance(obj, dict) else None


def iter_session_files(codex_home: pathlib.Path) -> list[pathlib.Path]:
    sessions = codex_home / "sessions"
    if not sessions.exists():
        return []
    return sorted(sessions.rglob("*.jsonl"))


def text_from_content(content: Any) -> str:
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for item in content:
        if isinstance(item, str):
            parts.append(item)
        elif isinstance(item, dict):
            text = item.get("text") or item.get("content")
            if isinstance(text, str):
                parts.append(text)
    return "\n".join(parts)


def compact_title(text: str, limit: int = 120) -> str:
    text = " ".join(text.split())
    for prefix in ["<environment_context>", "# AGENTS.md instructions"]:
        if text.startswith(prefix):
            return ""
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


def read_session_summary(path: pathlib.Path) -> dict[str, Any] | None:
    meta: dict[str, Any] | None = None
    first_user = ""
    last_ts: str | None = None

    try:
        lines = path.read_text(errors="replace").splitlines()
    except Exception as exc:
        return {"path": str(path), "error": str(exc)}

    for line in lines:
        obj = json_loads(line)
        if not obj:
            continue
        ts = obj.get("timestamp")
        if isinstance(ts, str):
            last_ts = ts
        payload = obj.get("payload") if isinstance(obj.get("payload"), dict) else {}
        if obj.get("type") == "session_meta" and meta is None:
            meta = payload
        if not first_user:
            if obj.get("type") == "response_item" and payload.get("type") == "message":
                if payload.get("role") == "user":
                    first_user = compact_title(text_from_content(payload.get("content")))
            elif obj.get("type") == "event_msg" and payload.get("type") == "user_message":
                msg = payload.get("message")
                if isinstance(msg, str):
                    first_user = compact_title(msg)

    if meta is None:
        return None

    sid = meta.get("id")
    if not isinstance(sid, str) or not sid:
        sid = path.stem[-36:]
    return {
        "id": sid,
        "path": str(path),
        "cwd": meta.get("cwd"),
        "model_provider": meta.get("model_provider"),
        "source": meta.get("source"),
        "created_at": meta.get("timestamp"),
        "updated_at": last_ts or meta.get("timestamp"),
        "title": first_user or sid,
    }


def collect_sessions(codex_home: pathlib.Path) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for path in iter_session_files(codex_home):
        summary = read_session_summary(path)
        if summary and summary.get("id"):
            out[str(summary["id"])] = summary
    return out


def connect_db(db: pathlib.Path) -> sqlite3.Connection:
    if not db.exists():
        raise SystemExit(f"Database not found: {db}")
    conn = sqlite3.connect(str(db))
    conn.row_factory = sqlite3.Row
    return conn


def table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}


def fetch_threads(conn: sqlite3.Connection) -> dict[str, sqlite3.Row]:
    return {row["id"]: row for row in conn.execute("SELECT * FROM threads")}


def print_counter(title: str, values: list[Any], limit: int = 20) -> None:
    print(f"\n{title}")
    for value, count in collections.Counter(values).most_common(limit):
        print(f"  {count:>4}  {value}")


def command_diagnose(args: argparse.Namespace) -> None:
    codex_home = codex_home_from_args(args.codex_home)
    db = pathlib.Path(args.db).expanduser() if args.db else newest_state_db(codex_home)
    sessions = collect_sessions(codex_home)
    conn = connect_db(db)
    threads = fetch_threads(conn)
    cols = table_columns(conn, "threads")

    active = [
        row
        for row in threads.values()
        if ("archived_at" not in cols or row["archived_at"] is None)
        and ("archived" not in cols or row["archived"] == 0)
    ]

    print(f"codex_home: {codex_home}")
    print(f"database: {db}")
    print(f"raw sessions: {len(sessions)}")
    print(f"db threads: {len(threads)}")
    print(f"active db threads: {len(active)}")

    index = codex_home / "session_index.jsonl"
    if index.exists():
        ids: list[str] = []
        bad = 0
        for line in index.read_text(errors="replace").splitlines():
            if not line.strip():
                continue
            obj = json_loads(line)
            if not obj:
                bad += 1
                continue
            sid = obj.get("id")
            if isinstance(sid, str):
                ids.append(sid)
        print(f"session_index: {len(ids)} lines, {len(set(ids))} unique, {bad} bad")
    else:
        print("session_index: missing")

    print(f"raw not in db: {len(set(sessions) - set(threads))}")
    for sid in sorted(set(sessions) - set(threads))[: args.limit]:
        print(f"  raw-only {sid} {sessions[sid]['path']}")

    print(f"db not raw: {len(set(threads) - set(sessions))}")
    for sid in sorted(set(threads) - set(sessions))[: args.limit]:
        print(f"  db-only {sid} {threads[sid]['rollout_path'] if 'rollout_path' in cols else ''}")

    if active:
        print_counter("active model_provider", [row["model_provider"] for row in active if "model_provider" in cols])
        print_counter("active source", [row["source"] for row in active if "source" in cols])
        print_counter("active cwd", [row["cwd"] for row in active if "cwd" in cols], args.limit)

    mismatches = []
    for sid, row in threads.items():
        sess = sessions.get(sid)
        if not sess:
            continue
        if "cwd" in cols and sess.get("cwd") != row["cwd"]:
            mismatches.append((sid, "cwd", row["cwd"], sess.get("cwd")))
        if "model_provider" in cols and sess.get("model_provider") != row["model_provider"]:
            mismatches.append((sid, "model_provider", row["model_provider"], sess.get("model_provider")))

    print(f"\nDB/JSONL metadata mismatches: {len(mismatches)}")
    for item in mismatches[: args.limit]:
        print("  ", item)


def require_apply(args: argparse.Namespace) -> None:
    if not args.apply:
        raise SystemExit("Dry run only. Re-run with --apply to write changes.")


def write_jsonl(path: pathlib.Path, objects: list[dict[str, Any]]) -> None:
    path.write_text("".join(json.dumps(obj, ensure_ascii=False) + "\n" for obj in objects))


def command_rebuild_index(args: argparse.Namespace) -> None:
    codex_home = codex_home_from_args(args.codex_home)
    sessions = collect_sessions(codex_home)
    rows = [
        {
            "id": sid,
            "thread_name": str(summary.get("title") or sid),
            "updated_at": str(summary.get("updated_at") or summary.get("created_at") or ""),
        }
        for sid, summary in sessions.items()
    ]
    rows.sort(key=lambda r: r.get("updated_at") or "", reverse=True)
    print(f"would write {len(rows)} rows to {codex_home / 'session_index.jsonl'}")
    if rows[:5]:
        print("top rows:")
        for row in rows[:5]:
            print("  ", row)
    require_apply(args)
    backup = backup_codex_home(codex_home, newest_state_db(codex_home), "rebuild_index", args.backup_sessions)
    write_jsonl(codex_home / "session_index.jsonl", rows)
    print(f"wrote index; backup: {backup}")


def update_jsonl_metadata(path: pathlib.Path, cwd: str | None = None, provider: str | None = None) -> int:
    changed = 0
    out: list[str] = []
    for line in path.read_text(errors="replace").splitlines(True):
        obj = json_loads(line)
        if not obj:
            out.append(line)
            continue
        payload = obj.get("payload") if isinstance(obj.get("payload"), dict) else None
        touched = False
        if payload is not None and obj.get("type") == "session_meta":
            if cwd is not None and payload.get("cwd") != cwd:
                payload["cwd"] = cwd
                touched = True
            if provider is not None and payload.get("model_provider") != provider:
                payload["model_provider"] = provider
                touched = True
        elif payload is not None and obj.get("type") == "turn_context":
            if cwd is not None and payload.get("cwd") != cwd:
                payload["cwd"] = cwd
                touched = True
        if touched:
            changed += 1
        out.append(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    if changed:
        path.write_text("".join(out))
    return changed


def command_fix_provider(args: argparse.Namespace) -> None:
    codex_home = codex_home_from_args(args.codex_home)
    db = pathlib.Path(args.db).expanduser() if args.db else newest_state_db(codex_home)
    conn = connect_db(db)
    cols = table_columns(conn, "threads")
    if "model_provider" not in cols:
        raise SystemExit("threads.model_provider does not exist")

    where = "" if args.include_archived else "WHERE archived_at IS NULL AND archived = 0"
    rows = list(conn.execute(f"SELECT id, rollout_path, model_provider FROM threads {where}"))
    current = collections.Counter(row["model_provider"] for row in rows)
    print(f"provider counts before: {dict(current)}")
    print(f"would set {len(rows)} threads to provider {args.provider!r}")
    require_apply(args)
    backup = backup_codex_home(codex_home, db, "provider_fix", args.backup_sessions)
    conn.execute(f"UPDATE threads SET model_provider=? {where}", (args.provider,))
    conn.commit()
    changed_files = 0
    changed_records = 0
    for row in rows:
        path = pathlib.Path(row["rollout_path"])
        if path.exists():
            n = update_jsonl_metadata(path, provider=args.provider)
            changed_records += n
            changed_files += 1 if n else 0
    print(f"updated DB and {changed_files} JSONL files ({changed_records} records); backup: {backup}")


def parse_assignments(values: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise SystemExit(f"Expected THREAD_ID=/path assignment, got: {value}")
        sid, cwd = value.split("=", 1)
        sid = sid.strip()
        cwd = cwd.strip()
        if not sid or not cwd.startswith("/"):
            raise SystemExit(f"Invalid assignment: {value}")
        out[sid] = cwd.rstrip("/") if cwd != "/" else cwd
    return out


def command_assign_cwd(args: argparse.Namespace) -> None:
    assignments = parse_assignments(args.assign_cwd)
    codex_home = codex_home_from_args(args.codex_home)
    db = pathlib.Path(args.db).expanduser() if args.db else newest_state_db(codex_home)
    conn = connect_db(db)
    rows = {}
    for sid in assignments:
        row = conn.execute("SELECT id, rollout_path, cwd, title FROM threads WHERE id=?", (sid,)).fetchone()
        if row is None:
            print(f"missing thread: {sid}")
        else:
            rows[sid] = row
            print(f"{sid}: {row['cwd']} => {assignments[sid]}  {row['title']}")
    require_apply(args)
    backup = backup_codex_home(codex_home, db, "cwd_project_fix", args.backup_sessions)
    for sid, row in rows.items():
        cwd = assignments[sid]
        conn.execute("UPDATE threads SET cwd=? WHERE id=?", (cwd, sid))
        path = pathlib.Path(row["rollout_path"])
        if path.exists():
            changed = update_jsonl_metadata(path, cwd=cwd)
            print(f"  JSONL {path.name}: {changed} records")
    conn.commit()
    print(f"updated {len(rows)} threads; backup: {backup}")


def load_global_state(codex_home: pathlib.Path) -> tuple[pathlib.Path, dict[str, Any]]:
    path = codex_home / ".codex-global-state.json"
    if not path.exists():
        return path, {}
    return path, json.loads(path.read_text(errors="replace"))


def command_assign_projects(args: argparse.Namespace) -> None:
    assignments = parse_assignments(args.assign_cwd)
    codex_home = codex_home_from_args(args.codex_home)
    db = pathlib.Path(args.db).expanduser() if args.db else newest_state_db(codex_home)
    path, state = load_global_state(codex_home)
    project_assignments = state.get("thread-project-assignments")
    if not isinstance(project_assignments, dict):
        project_assignments = {}
    for sid, cwd in assignments.items():
        project_assignments[sid] = {
            "projectKind": "local",
            "projectId": cwd,
            "path": cwd,
            "pendingCoreUpdate": False,
        }
        print(f"would assign {sid} to {cwd}")
    state["thread-project-assignments"] = project_assignments

    roots = sorted(set(assignments.values()))
    for key in ["electron-saved-workspace-roots", "active-workspace-roots", "project-order"]:
        arr = state.get(key)
        if not isinstance(arr, list):
            arr = []
        for root in roots:
            if root not in arr:
                arr.append(root)
        state[key] = arr

    persisted = state.setdefault("electron-persisted-atom-state", {})
    if isinstance(persisted, dict) and isinstance(persisted.get("sidebar-collapsed-groups"), dict):
        persisted["sidebar-collapsed-groups"] = {}

    require_apply(args)
    backup = backup_codex_home(codex_home, db, "project_assignments", args.backup_sessions)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n")
    print(f"wrote {path}; backup: {backup}")


def command_verify(args: argparse.Namespace) -> None:
    codex_home = codex_home_from_args(args.codex_home)
    db = pathlib.Path(args.db).expanduser() if args.db else newest_state_db(codex_home)
    conn = connect_db(db)
    active = list(conn.execute("SELECT id, cwd, model_provider FROM threads WHERE archived_at IS NULL AND archived = 0"))
    print(f"active sqlite threads: {len(active)}")
    print_counter("sqlite cwd", [row["cwd"] for row in active], args.limit)

    bad = []
    for row in conn.execute("SELECT id, rollout_path, cwd, model_provider FROM threads WHERE archived_at IS NULL AND archived = 0"):
        path = pathlib.Path(row["rollout_path"])
        if not path.exists():
            bad.append((row["id"], "missing_file", str(path)))
            continue
        summary = read_session_summary(path)
        if not summary:
            bad.append((row["id"], "bad_session_meta", str(path)))
            continue
        if summary.get("cwd") != row["cwd"]:
            bad.append((row["id"], "cwd_mismatch", row["cwd"], summary.get("cwd")))
        if summary.get("model_provider") != row["model_provider"]:
            bad.append((row["id"], "provider_mismatch", row["model_provider"], summary.get("model_provider")))
    print(f"metadata mismatches: {len(bad)}")
    for item in bad[: args.limit]:
        print("  ", item)

    if args.app_server:
        verify_app_server(pathlib.Path(args.app_server), args.limit)


def rpc_read(stdout: Any, expected_id: int) -> dict[str, Any]:
    while True:
        line = stdout.readline()
        if not line:
            raise RuntimeError("app-server closed before response")
        obj = json_loads(line)
        if obj and obj.get("id") == expected_id:
            return obj


def verify_app_server(codex_binary: pathlib.Path, limit: int) -> None:
    cmd = [str(codex_binary), "app-server", "--listen", "stdio://"]
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    next_id = 1

    def call(method: str, params: dict[str, Any]) -> Any:
        nonlocal next_id
        msg = {"jsonrpc": "2.0", "id": next_id, "method": method, "params": params}
        assert proc.stdin is not None
        assert proc.stdout is not None
        proc.stdin.write(json.dumps(msg) + "\n")
        proc.stdin.flush()
        response = rpc_read(proc.stdout, next_id)
        next_id += 1
        if "error" in response:
            raise RuntimeError(response["error"])
        return response.get("result")

    try:
        call("initialize", {"clientInfo": {"name": "restore-codex-history", "version": "1.0"}})
        result = call(
            "thread/list",
            {
                "limit": 200,
                "cursor": None,
                "sortKey": "updated_at",
                "modelProviders": None,
                "archived": False,
                "sourceKinds": [],
            },
        )
        data = result.get("data") or []
        print(f"\napp-server thread/list: {len(data)} rows, nextCursor={result.get('nextCursor')}")
        print_counter("app-server providers", [row.get("modelProvider") for row in data], limit)
        print_counter("app-server cwd", [row.get("cwd") for row in data], limit)
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=3)
        except Exception:
            proc.kill()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    shared = argparse.ArgumentParser(add_help=False)
    shared.add_argument("--codex-home", help="Codex home directory, default $CODEX_HOME or ~/.codex")
    shared.add_argument("--db", help="Path to state_*.sqlite, default newest in Codex home")
    shared.add_argument("--limit", type=int, default=20, help="Maximum rows to print per section")
    shared.add_argument("--apply", action="store_true", help="Actually write changes")
    shared.add_argument("--no-backup-sessions", dest="backup_sessions", action="store_false", help="Do not copy sessions/ into backups")
    for action in shared._actions:
        if action.option_strings:
            parser._add_action(action)
    parser.set_defaults(backup_sessions=True)

    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("diagnose", parents=[shared])
    sub.add_parser("rebuild-index", parents=[shared])

    fix_provider = sub.add_parser("fix-provider", parents=[shared])
    fix_provider.add_argument("--provider", required=True)
    fix_provider.add_argument("--include-archived", action="store_true")

    assign_cwd = sub.add_parser("assign-cwd", parents=[shared])
    assign_cwd.add_argument("--assign-cwd", action="append", required=True, help="THREAD_ID=/absolute/project/root")

    assign_projects = sub.add_parser("assign-projects", parents=[shared])
    assign_projects.add_argument("--assign-cwd", action="append", required=True, help="THREAD_ID=/absolute/project/root")

    verify = sub.add_parser("verify", parents=[shared])
    verify.add_argument("--app-server", help="Path to Codex binary that supports app-server")

    return parser


def main() -> None:
    args = build_parser().parse_args()
    commands = {
        "diagnose": command_diagnose,
        "rebuild-index": command_rebuild_index,
        "fix-provider": command_fix_provider,
        "assign-cwd": command_assign_cwd,
        "assign-projects": command_assign_projects,
        "verify": command_verify,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
